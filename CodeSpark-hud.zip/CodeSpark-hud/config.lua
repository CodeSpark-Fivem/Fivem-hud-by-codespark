Config = {}




Config.showMoneyContainer = true -- Set this to false to hide the money container
Config.EnableNeedsBar = false -- Set to false to disable food & water UI
