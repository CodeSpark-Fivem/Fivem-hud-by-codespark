
SendNUIMessage({
    action = "setConfig",
    showJob = Config.ShowJob
})



-- spidometras-- spidometras-- spidometras-- spidometras-- spidometras-- spidometras-- spidometras-- spidometras-- spidometras-- spidometras-- spidometras-- spidometras-- spidometras
local pauseDetected, uiReady = false, false
local speedometerShown, seatbeltOn = false, false

local hudDisabled = {
    speedo = false
}

local vehicle = cache.vehicle

lib.onCache('vehicle', function(value)
    onVehicle(value)
end)

RegisterNUICallback('hudReady', function()
    uiReady = true

    SendNUIMessage({
        action = 'updateElement',
        element = 'playerId',
        content = serverId
    })

    SendNUIMessage({
        action = 'toggleElement',
        element = '#wrapper',
        toggle = true,
    })

    SendNUIMessage({
        action = 'toggleSpeed',
        toggle = false
    })

    Wait(500)
    onVehicle(vehicle)
end)

CreateThread(function()
    while not uiReady do
        Wait(100)
    end
    
    while true do
       

        if not IsPauseMenuActive() then
            if pauseDetected then
                if not hudDisabled.main then
                    SendNUIMessage({
                        action = 'toggleElement',
                        element = '#wrapper',
                        toggle = true,
                    })

                    pauseDetected = false
                end
            elseif not hudDisabled.main then
               

                SendNUIMessage({
                    action = 'updateStatus',
                    
                })
            end
        elseif not pauseDetected and not hudDisabled.main then
            SendNUIMessage({
                action = 'toggleElement',
                element = '#wrapper',
                toggle = false,
            })

            pauseDetected = true
        end

        Wait(500)
    end
end)

function onVehicle(value)
    vehicle = value

    if vehicle then
        

        if not speedometerShown and not hudDisabled.speedo then
            speedometerShown = true

            SendNUIMessage({
                action = 'toggleSpeed',
                toggle = true
            })
        end

        CreateThread(function()
            while vehicle do
                Wait(100)

                SendNUIMessage({
                    action = 'changeSpeed',
                    type = 'engine',
                    toggle = GetVehicleEngineHealth(vehicle) <= 400.0,
                })

                SendNUIMessage({
                    action = 'changeSpeed',
                    type = 'lock',
                    toggle = GetVehicleDoorLockStatus(vehicle) ~= 1,
                })

                if GetIsVehicleEngineRunning(vehicle) then
                    SendNUIMessage({
                        action = 'updateSpeed',
                        speed = round(GetEntitySpeed(vehicle) * 3.6),
                        fuel = round(Entity(vehicle).state.fuel or 0),
                        rpm = round(GetVehicleCurrentRpm(vehicle), 3),
                    })
                else
                    SendNUIMessage({
                        action = 'updateSpeed',
                        speed = round(GetEntitySpeed(vehicle) * 3.6),
                        fuel = round(tonumber(Entity(vehicle).state.fuel) or 0),
                        rpm = 0,
                    })
                    
                    Wait(200)
                end
            end

         
        end)

        CreateThread(function()
            while vehicle do
                local engineHealth = GetVehicleEngineHealth(vehicle)
                local vehicleSpeed = math.floor(GetEntitySpeed(vehicle) * 3.6)

                if lastEngineHealth and lastVehicleSpeed and vehicleVelocity then
                    if engineHealth - lastEngineHealth < -50 and vehicleSpeed - lastVehicleSpeed < -50 then
                        
                    end
                end

                lastEngineHealth = engineHealth
                lastVehicleSpeed = vehicleSpeed
                vehicleVelocity = GetEntityVelocity(vehicle)

                Wait(100)
            end
        end)
    else
        if speedometerShown then
            speedometerShown = false

            if not hudDisabled.speedo then
                SendNUIMessage({
                    action = 'updateSpeed',
                    speed = 0,
                    fuel = 0,
                    rpm = 0
                })

                SendNUIMessage({
                    action = 'toggleSpeed',
                    toggle = false
                })
            end
        end

       

        if lastEngineHealth then
            lastEngineHealth = nil
            lastVehicleSpeed = nil
            vehicleVelocity = nil
        end

        cruiseEnabled = nil
    end
end

function round(num, numDecimalPlaces)
    local mult = 10^(numDecimalPlaces or 0)
    return math.floor(num * mult + 0.5) / mult
end

exports('isHudActive', function()
    return not hudDisabled.main
end)

Citizen.CreateThread(function()
    local minimap = RequestScaleformMovie("minimap")
    SetRadarBigmapEnabled(false, false)
    while true do
        Wait(0)
        BeginScaleformMovieMethod(minimap, "SETUP_HEALTH_ARMOUR")
        ScaleformMovieMethodAddParamInt(3)
        EndScaleformMovieMethod()
    end
end)



-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai-- statusai


function getPlayerHealth()
    return (GetEntityHealth(PlayerPedId()) - 100) / 100 * 100 
end

function getPlayerArmor()
    return GetPedArmour(PlayerPedId()) 
end

function getPlayerFood()
    if not Config.EnableNeedsBar then return 0 end
    local hunger = 0
    TriggerEvent('esx_status:getStatus', 'hunger', function(status)
        hunger = status.val / 10000 
    end)
    return hunger
end

function getPlayerWater()
    if not Config.EnableNeedsBar then return 0 end
    local thirst = 0
    TriggerEvent('esx_status:getStatus', 'thirst', function(status)
        thirst = status.val / 10000 
    end)
    return thirst
end


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000) 

       
        local health = getPlayerHealth()
        local armor = getPlayerArmor()
        local food = getPlayerFood()
        local water = getPlayerWater()

        
        SendNUIMessage({
            action = "updateBars",
            health = health,
            armor = armor,
            food = food,
            water = water,
            showNeeds = Config.EnableNeedsBar 
        })
    end
end)


-- Client-side Lua (client.lua)
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000) -- Update every second

        -- Get the player's ID
        local playerID = GetPlayerServerId(PlayerId())

        -- Send the player ID to the NUI (HTML interface)
        SendNUIMessage({
            action = 'displayPlayerID',  
            playerID = playerID         -- Pass the player ID
        })
    end
end)



RegisterNetEvent('updatePlayerCount')
AddEventHandler('updatePlayerCount', function(playerCount)
   
    SendNUIMessage({
        action = 'updatePlayerCount',
        playerCount = playerCount
    })
end)

local playerMoney = 0
local playerBank = 0

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5000) 
        TriggerServerEvent('hud:requestMoney') 
    end
end)

RegisterNetEvent('hud:updateMoney')
AddEventHandler('hud:updateMoney', function(cash, bank)
    playerMoney = cash
    playerBank = bank
    SendNUIMessage({
        action = "updateMoney",
        cash = playerMoney,
        bank = playerBank
    })
end)

RegisterNetEvent('esx:setAccountMoney')
AddEventHandler('esx:setAccountMoney', function(account)
    if account.name == 'money' then
        playerMoney = account.money
    elseif account.name == 'bank' then
        playerBank = account.money
    end

    SendNUIMessage({
        action = "updateMoney",
        cash = playerMoney,
        bank = playerBank
    })
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)  
        
        
        SendNUIMessage({
            action = 'toggleMoneyContainer', 
            show = Config.showMoneyContainer  -- True or False based on the config
        })
    end
end)


ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(100)
    end

    while not ESX.IsPlayerLoaded() do
        Citizen.Wait(100)
    end

    SendJobToNUI()
end)

function SendJobToNUI()
    local playerData = ESX.GetPlayerData()
    if playerData and playerData.job then
        SendNUIMessage({
            action = "updateJob",
            job = playerData.job.name,  -- raw job identifier, e.g., 'police'
            label = playerData.job.label -- display name, e.g., 'Police'
        })
    end
end

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    ESX.PlayerData = xPlayer
    SendJobToNUI()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
    ESX.PlayerData.job = job
    SendJobToNUI()
end)


