ESX = exports['es_extended']:getSharedObject()

RegisterNetEvent('updatePlayerStats')
AddEventHandler('updatePlayerStats', function(health, armor, food, water)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        MySQL.Async.execute('UPDATE users SET health = @health, armor = @armor, food = @food, water = @water WHERE identifier = @identifier', {
            ['@health'] = health,
            ['@armor'] = armor,
            ['@food'] = food,
            ['@water'] = water,
            ['@identifier'] = xPlayer.identifier
        }, function(affectedRows)
            if affectedRows > 0 then
                print("Player stats updated successfully.")
            end
        end)
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5000)
        local playerCount = GetNumPlayerIndices()
        TriggerClientEvent('updatePlayerCount', -1, playerCount)
    end
end)

RegisterNetEvent('hud:requestMoney')
AddEventHandler('hud:requestMoney', function()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer then
        local cash = xPlayer.getMoney() or 0
        local bank = xPlayer.getAccount('bank').money or 0
        TriggerClientEvent('hud:updateMoney', src, cash, bank)
    end
end)
