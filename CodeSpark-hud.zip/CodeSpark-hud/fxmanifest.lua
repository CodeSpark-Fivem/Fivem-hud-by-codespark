fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'CodeSpark'
description 'ESX hud by CodeSpark'

shared_scripts {
    'config.lua', 
    '@es_extended/imports.lua',
    '@ox_lib/init.lua'
}

client_script 'client.lua'
server_script 'server.lua'

ui_page 'html/index.html'
files {
    'html/**',
}