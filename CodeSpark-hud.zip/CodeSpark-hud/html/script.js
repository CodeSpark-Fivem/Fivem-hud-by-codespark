

$(function () {


    var rpmTrail = new ProgressBar.Circle('#rpmTrail', {
        strokeWidth: 8,
        duration: 100,
        color: 'rgba(0, 0, 0, 0.6)'
    });

    var rpmDisplay = new ProgressBar.Circle('#rpmDisplay', {
        strokeWidth: 8,
        duration: 100,
        color: 'rgb(255, 255, 255)', 
    });

    var fuelTrail = new ProgressBar.Circle('#fuelTrail', {
        strokeWidth: 6,
        duration: 100,
        color: 'rgba(0, 0, 0, 0.6)'
    });

	var fuelDisplay = new ProgressBar.Circle('#fuelDisplay', {
        strokeWidth: 6,
        duration: 100,
        color: 'rgb(255, 230, 4)' 
    });

	function getFuelColor(fuel) {
        let color;
        if (fuel > 40) {
            color = 'rgb(255, 230, 4)';  
        } else if (fuel > 20) {
            color = 'rgb(255, 140, 0)'; 
        } else {
            color = 'rgb(255, 0, 0)';    
        }
    
   
        const fuelTrail = document.getElementById('fuelDisplay');
        if (fuelTrail) {
            fuelTrail.style.filter = `drop-shadow(0 0 2px ${color}) drop-shadow(0 0 2px ${color})`;
        }
    
        return color;
    }

    fuelTrail.set(0.40);
    rpmTrail.set(0.75);

    function getRPMColor(rpm) {
        let r, g;
    
        if (rpm < 0.5) {
            r = 0;
            g = 255;
        } else if (rpm < 0.75) {
            r = (rpm - 0.5) * 1020; 
            g = 255;
        } else {
            r = 255;
            g = 255 - (rpm - 0.75) * 1020;
        }
    
        
        const color = `rgb(${Math.min(255, Math.max(0, r))}, ${Math.min(255, Math.max(0, g))}, 0)`;
    
    
        const rpmTrail = document.getElementById('rpmDisplay');
        if (rpmTrail) {
            rpmTrail.style.filter = `drop-shadow(0 0 2px ${color}) drop-shadow(0 0 2px ${color})`;
        }
    
       
        return color;
    }
    

    $.post(`https://${GetParentResourceName()}/hudReady`);

    window.addEventListener('message', (event) => {
        var data = event.data;
    
        if (data.action == 'updateSpeed') {
            var carSpeed = data.speed.toString().padStart(3, '0');
            let rpmColor = getRPMColor(data.rpm);
            let fuelColor = getFuelColor(data.fuel);
    
            const speedText = document.getElementById('speedText');
            if (speedText) {
                speedText.innerText = carSpeed;
                speedText.style.color = rpmColor;
            }
    
            let fuelPercentage = (data.fuel / 100) * 0.40;
            if (fuelDisplay) {
                fuelDisplay.animate(fuelPercentage);
                fuelDisplay.path.setAttribute("stroke", fuelColor);
            }
    
            if (rpmDisplay) {
                rpmDisplay.animate(data.rpm * 0.75);
                rpmDisplay.path.setAttribute("stroke", rpmColor);
            }
        } else if (data.action == 'toggleSpeed') {
            const speedHud = $('#speedHud');
            if (speedHud) {
                if (data.toggle) {
                    speedHud.fadeIn();
                } else {
                    speedHud.fadeOut();
                }
            }
        } else if (data.action == 'updateElement') {
            const element = document.getElementById(data.element);
            if (element) {
                element.innerHTML = data.content;
            }
        } else if (data.action == 'toggleElement') {
            const element = $(data.element);
            if (element) {
                if (data.toggle) {
                    element.fadeIn();
                } else {
                    element.fadeOut();
                }
            }
        }
        
    });
    
});


window.addEventListener('message', function (event) {
    if (event.data.action === 'updateBars') {
        let health = event.data.health;
        let armor = event.data.armor;
        let food = event.data.food;
        let water = event.data.water;
        const showNeeds = event.data.showNeeds; 

        
        if (health < 0) {
            health = 0;
        }
        

        health = Math.round(health);
        armor = Math.round(armor);
        food = Math.round(food);
        water = Math.round(water);

    
        document.getElementById('healthProgress').style.width = `${health}%`;
        document.getElementById('shieldProgress').style.width = `${armor}%`;

     
        document.getElementById('healthText').textContent = health;
        document.getElementById('shieldText').textContent = armor;

   
        const foodBar = document.getElementById('foodBarContainer');
        const waterBar = document.getElementById('waterBarContainer');

        if (showNeeds) {
            foodBar.style.display = "flex";
            waterBar.style.display = "flex";
            document.getElementById('foodProgress').style.width = `${food}%`;
            document.getElementById('waterProgress').style.width = `${water}%`;

        
            document.getElementById('foodText').textContent = food;
            document.getElementById('waterText').textContent = water;
        } else {
            foodBar.style.display = "none";
            waterBar.style.display = "none";
        }
    }
});




window.addEventListener('message', function(event) {
    if (event.data.action === 'displayPlayerID') {
        const playerID = event.data.playerID;
    
        document.getElementById('playerID').textContent = `Id: ${playerID}`;
    }
});


window.addEventListener('message', (event) => {
    var data = event.data;

    if (data.action === 'updatePlayerCount') {
       
        var playerCount = data.playerCount;

       
        document.getElementById('playerCount').innerText = `Žaidėjai: ${playerCount}`;
    }
});

window.addEventListener("message", function(event) {
    if (event.data.action === "updateMoney") {
       
        document.getElementById("cashAmount").textContent = `${Number(event.data.cash).toLocaleString()}`;
        document.getElementById("bankAmount").textContent = `${Number(event.data.bank).toLocaleString()}`;
    }
});


window.addEventListener('message', function(event) {
    if (event.data.action === 'toggleMoneyContainer') {
        const moneyContainer = document.getElementById('moneyContainer');
        if (event.data.show) {
            moneyContainer.style.display = 'block'; 
        } else {
            moneyContainer.style.display = 'none';   
        }
    }
});

window.addEventListener('message', function(event) {
    if (event.data.action === 'updateJob') {
       
        document.getElementById('jobName').innerText = event.data.label;

        
        var job = event.data.job.toLowerCase();
        var jobIcon = document.getElementById('jobIcon');
        
       

       
            
    }
});
